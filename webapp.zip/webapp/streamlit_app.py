import streamlit as st
import pandas as pd
from PIL import Image
from openpyxl import load_workbook
from pathlib import Path


def display_image(img_path):
    markdown_text = f"""
    <div style="background-color: purple; padding: 3px; border-radius: 1px;">
    </div>
    """
        
    #Display the image within the styled container
    st.markdown(markdown_text, unsafe_allow_html=True)
    st.image(str(img_path), use_column_width=False,width=100)
    st.markdown(markdown_text, unsafe_allow_html=True)

def read_excel(file_path):
    workbook = load_workbook(filename=file_path)
    sheet_names = workbook.sheetnames
    dataframes={}
    for sheet_name in sheet_names:
        df = pd.read_excel(file_path, sheet_name=sheet_name)
        dataframes[sheet_name] = df
    
    return (sheet_names,dataframes)


def execute_webapp(file_path,img_path,file_op_path):
    file_name = file_path.name
    file_type = file_path.suffix
    display_image(img_path)
    markdown_text = f"""
    <div style="background-color:  #D6B4CB ; padding: 10px; border-radius: 5px;">
        <span style="color: black;"><b>Currently Showing  :    <i>{file_name}</i?</b>
        </span>
    </div>
    """

    st.markdown(markdown_text, unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)
    # Set df to none
    df = None
    if file_type=='.csv':
        df = pd.read_csv(file_path)
        edited_df = st.data_editor(df)
    elif file_type in ('.xlsx','.xls'):
        sheetnames,dataframes=read_excel(file_path)
        choice = st.sidebar.selectbox("Menu", sheetnames)
        df = dataframes[choice]
        edited_df = st.data_editor(df)
        dataframes[choice]=edited_df
    
    if df is None:
        raise Exception('No Data was extracted')

    markdown_text = f"""
    <div style="background-color: purple; padding: 3px; border-radius: 1px;">
    </div>
    """
        
    #Display the image within the styled container
    st.markdown(markdown_text, unsafe_allow_html=True)

    # Text input to get the file path
    markdown_text = f"""
    <div style="background-color:  #D6B4CB ; padding: 10px; border-radius: 5px;">
        <span style="color: black;"><b>Enter the name of the file to be saved as: </b>
        </span>
    </div>
    """
    st.markdown(markdown_text, unsafe_allow_html=True)
    file_name = st.text_input("")

    if st.button("Save DataFrame"):
        file_path = file_op_path.joinpath(f'{file_name}.{file_type}')
        if file_type in ('xlsx','xls'):
            
            file_type = 'csv'
        edited_df.to_csv(file_path, index=False)
        st.success(f"File saved successfully at {file_path}") 

def display_app():
    
    parent_dir = Path(__file__).resolve().parent

    file_path = parent_dir.joinpath('jcp_style_map_ref.csv')
    img_path = parent_dir.joinpath('hbi_logo.png')
    file_op_path = parent_dir.joinpath('output')
    # print(file_path.suffix)
    execute_webapp(file_path,img_path,file_op_path)

if __name__=="__main__":
    display_app()
